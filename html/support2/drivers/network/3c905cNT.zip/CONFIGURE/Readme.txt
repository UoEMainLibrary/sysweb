                        3Com (R) Corporation
                   3C90x EtherLink PCI NIC Family
            Release Notes and Frequently Asked Questions


--------------------------------------------------------------------------

The EtherCD version 5.1 CD-ROM supports 3Com's family of 
EtherLink 10/100 PCI bus-mastering network interface cards (NICs) 
with a common driver set.  Key product features include:

-   Parallel Tasking II (R) architecture for high performance
-   Bus mastering for low CPU utilization and optimal overall 
    system performance 
-   Automatic selection of media type for EtherLink 10/100 Mbps NICs
-   Automatic selection of link speed for EtherLink 10/100 Mbps NICs
-   Broad driver support, including NetWare, NDIS 2.01, NDIS 3.0, 
    NDIS 4.0, NDIS 5.0, and others 
-   SNMP manageability
-   Lifetime limited warranty 
-   Full duplex enabled for switched 10/100 Mbps environments

                             
Release Notes and Frequently Asked Questions
--------------------------------------------

This file contains release notes and answers to some frequently 
asked questions to help you obtain maximum performance from your 
3Com EtherLink NIC.  This information is updated regularly on 
3Com's World Wide Web site (www.3Com.com) and BBS (bulletin board 
service).
                              

    Release Notes
    -------------

        >>> 3Com NIC Diagnostics program for Windows not available 
            in Windows 95 (Retail)

        If the 3Com NIC Diagnostics program for Windows is not 
        available in the Windows Start menu (under Programs, 
        3Com NIC Utilities, 3Com NIC Doctor), run the program
        manually:

           1.  Open the Windows Start menu and select Run.

           2.  Type TCAUDIAG, and then click OK.

           3.  Select the Show Icon in System Tray check box 
               to enable the 3Com icon to appear in the Windows 
               system tray. Double-click the icon to start the 
               3Com NIC Diagnostic program.


        >>> Potential problem when sharing interrupts under 
            Windows 95

        If you install two or more PCI devices (one of them being an  
        EtherLink 10 Mbps NIC) that use the same interrupt in your 
        Windows 95 system, your system may exhibit strange behavior.  

        3Com has found that sharing interrupts can cause a blue screen 
        error or continuous system reboots, which are caused by disabling 
        or enabling the NIC using the Windows Device Manager or the 3Com 
        NIC Diagnostics program.  This problem has been found on multiple 
        systems and with other manufacturer's PCI devices.
        
        The solution is to stop sharing the interrupt between the devices
        and assign a different PCI interrupt number to each of the 
        devices. Changing the PCI interrupt that is assigned to a 
        device is a function of the BIOS or a utility provided by 
        the PC Manufacturer.  For more details, refer to the 
        documentation provided with your PC or contact your PC manufacturer.
                

        >>> Spurious hardware interrupts on the Compaq Proliant 5000

        When running a server on the Compaq Proliant 5000, numerous 
        "Spurious Interrupts" warning messages may appear.  3Com has found 
        that these warnings should be ignored and have no effect with normal 
        operation.  3Com has noticed that these warnings also happen with 
        NICs from other manufacturing companies.
        
        
        >>> Performance hint for EtherLink NICs in HP NetServers

        During testing of HP NetServers and the EtherLink NIC,
        3Com has observed that the performance can be maximized by 
        customizing the NetServer's BIOS.  Within the BIOS of the NetServer, 
        access the Advanced Chipset Setup and set the DRAM Buffer Write to 
        0 and the Snoop Ahead to 1.  
        
        NOTE: This was tested on an HP NetServer 466 LF and a 466 LC, but 
              could apply to other models of the NetServer family.


        >>> Warm booting with the DOS-based drivers running

        3Com has found that some systems do not reset the PCI Bus when the
        <CTRL>+<ALT>+<DEL> key combination (a "warm boot") is used to restart 
        the PC.  If the system does not reset the PCI Bus when a warm boot
        occurs, the EtherLink NIC remains in a running state that can cause 
        problems if there is any network activity before the driver is 
        reloaded. This problem can be avoided by pressing the PC's reset 
        button (if your PC has one) or by turning the PC completely off 
        before restarting.  

        
        >>> Unable to use network connections after running diagnostic tests

        When using an EtherLink 3C900-COMBO NIC, 3Com has found that
        running the diagnostic tests included in the 3Com NIC Diagnostics 
        program for Windows may cause you to lose your network connections 
        and make it unable to create any new connections.  To correct this
        problem, reboot the PC.
                     

        >>> Windows NT and S3 video driver

        During testing, 3Com has observed a problem that occurs with 
        Windows NT involving S3 video drivers and PCI memory mapped I/O 
        devices installed on the secondary PCI bus. A symptom includes 
        system lock-up upon initialization of Windows NT.

        The problem has been observed with the Dell OptiPlex GXPro 6/180
        using the 3C905B NIC with Windows NT 4.0, Service Pack 3.
        Updating the video driver for the S3 Trio64V+ (765DRV - version
        2.00.18) resolves the issue. This problem can also be resolved by
        installing the 3C905B NIC in the primary PCI bus or by uninstalling
        Service Pack 3.

        The S3 driver included with Service Pack 3 for Windows NT has a 
        problem where it makes several writes to unclaimed memory space 
        in the PCI bridge chip, causing Windows NT to become unstable and hang.


        >>> NetServer LS2 5/166 and 3C90xB NICs running Windows NT4.0 with
        >>> Service Pack 3

        3Com has noticed that when a 3C90xB NIC is installed in the
        secondary PCI bus of a NetServer LS2 5/166 PC, the PC may hang
        intermittently.  The possible symptoms include a locked mouse
        pointer, steady hourglass, or the inability to execute any programs.
        To correct this problem, install the NIC in the primary PCI bus.  
        This problem has observed only in this model of the NetServer and not 
        on other machines of the NetServer line.  3Com is currently working with 
        HP to resolve this issue.  


        >>> Using an SNI machine with the 82440LX chip set running NetWare 4.1
        >>> causes the server to abend with a stack overflow error

        If the SNI machine with the 440LX chip set is running NetWare with
        an Adaptec SCSI card and a 3C90xB NIC installed, and a stack
        overflow occurs, contact Adaptec or SNI for an updated SCSI
        driver for the machine.


        >>> HP Vectra VL 5200

        3Com has observed during testing that the 3C905B NIC using the
        NDIS 4 driver under Windows 95 OSR2 (version b) causes the PC to
        boot in Safe Mode. There is no known workaround at this time.  3Com
        is working with HP on a resolution.


        >>> ASUS P2B motherboard

        3Com has observed that the 3C905B-TX NIC may not work properly in
        the ASUS P2B motherboard.  Symptoms may include Remote Wake-Up or the
        BIOS not identifying the NIC correctly. This issue is fixed by ASUS 
        with P2B BIOS Ver. 1005. 08/01/98. You can download the new BIOS, or 
        the latest available BIOS, from the ASUS Web site: http://www.asus.com


        >>> DOS diagnostics incompatibility with 3C905B NIC and Gateway E-3000

        During testing, 3Com encountered incompatibilities with the 3C905B
        NIC and the Gateway E-3000 series PC when loading the 3Com Configuration
        and Diagnostics program for DOS. 3Com suggests using the 3Com NIC 
        Diagnostics program for Windows if you encounter this problem. 
        This happens if PnP OS is enabled in the BIOS settings, because DOS
        is not a plug-and-play operating system.  
        

        >>> 3C905B NICs not supported in the NEC PowerMate P2200: P5 200MHz PC

        3Com has observed incompatibilities with the 3C905B family of
        NICs and the NEC PowerMate P2200: P5 200MHz PC. Intermittent
        network connection errors were observed during testing and no known
        workarounds are available at this time. 3Com suggests not using the
        3C905 or 3C905B NIC in this particular PC.


        >>> 3C905C NICs not supported in the AT&T Globalyst 550 (486/100MHz) PC
    
        3Com has observed incompatibilities with the 3C905C NIC installed in
        an AT&T Globalyst 550 (486/100MHz) PC with BIOS version 1.11. 3Com
        suggests not using the 3C905C NIC in this particular PC.


        >>> Micron Powerdign Xsu with 300Mhz Pentium II

        3Com has observed that the Micron Powerdign Xsu with 300Mhz
        Pentium II may occasionally hang or loose network connection
        when a 3C90x NIC is installed in the 64-bit slot of this system.
        For this particular PC, the 64-bit slot is not supported and
        3Com suggests using any available PCI slot other than the 64-bit 
        slot in this system.   


        >>> 3Com PCI NIC installation hints

            >>> Installing a PCI NIC in a PCI slot

            1.  Install the NIC in the computer. Refer to the NIC's user guide
                or to the computer's documentation for complete installation 
                instructions.
            
            2.  Start the computer. In most cases, the PCI computer automatically 
                configures the NIC.  If this does not happen, you may need 
                to configure the PC to work with the NIC. See the next section 
                for more details.

            >>> Troubleshooting installation problems

            3Com has found that some PCI computers require additional 
            configuration steps in order to install a PCI NIC.  3Com 
            recommends these steps:
      
            1.  Determine whether you have the latest BIOS version for your 
                computer.  Contact your computer's manufacturer to make 
                sure that you are using the latest BIOS. 

            2.  Make sure that the BIOS is set up correctly.  In some PCI 
                computers, you may need to enable the PCI slot using the 
                BIOS Setup program.  This is especially common in PCI 
                computers with a Phoenix BIOS.

                After installing the NIC, turn on the computer and 
                enter the Setup program during system initialization 
                (usually by pressing [F1], [F2], or [Ctrl]+[Alt]+[S]). 
                The correct key to press is usually shown on the screen.
                Once in the Setup program, find the entry for PCI slots 
                (it may be in the main menu, or sometimes in advanced 
                system configuration) and set these parameters to:

                BIOS System          Setting 
                Parameter

                PCI Slot Number      Slot where the 3Com PCI NIC is 
                                     installed (1-3)
                Master               ENABLED
                Slave                ENABLED
                Latency Timer        40
                Interrupt            Choose any one of several available
                                     interrupts that Setup provides.
                Edge or Level        Level Triggered Interrupt

                NOTE: The exact wording of each of the parameters 
                      varies from computer to computer. Save the changes, 
                      exit the Setup program, and continue with the
                      installation.
       

        >>> Echo Exchange Test using a crossover cable

        The Echo Exchange Test verifies the NIC's ability to
        transmit and receive data while on the network.  There are two
        ways to perform the Echo Exchange Test:
      
        --Connect two PCs to the same network (using a hub or switch).
        --Connect two PCs directly to each other using a crossover
          cable.

        Connecting Two PCs to the Same Network
        --------------------------------------
        1. Connect one PC (the echo server) and another PC (the 
           echo client) together through a hub or a switch that 
           generates a constant link beat.  

        2. Set each NICs' Media Type and Duplex settings to AutoSelect.

        3. Run the Echo Exchange Test.

        Connecting Two PCs Using a Crossover Cable          
        ------------------------------------------              
        1. Connect the two PCs together using a crossover cable.

        2. Manually set the Media Type to 10 Mbps or 100 Mbps and 
           the Duplex mode to full or half duplex.

        3. Run the Echo Exchange Test.  
        

        >>> Running the DOS ODI driver with a Non-Novell protocol in DOS

        Add the keyword NO_PIPELINE to your NET.CFG file when running the 
        DOS ODI driver with a non-Novell protocol in a DOS environment.  
        To add the keyword NO_PIPELINE to your NET.CFG file:

        1.  Access the C:\NWCLIENT directory and open the NET.CFG file.  
            Type: 
     
            EDIT NET.CFG [Enter]

        2.  Scroll through the file to the LINK DRIVER 3C90X section and 
            locate the following line:

            LINK DRIVER 3C90X

        3.  Add NO_PIPELINE after LINK DRIVER 3C90X.  Your file should 
            now look like this:

            LINK DRIVER 3C90X
            NO_PIPELINE    {<- make sure this is indented a few spaces }


        >>> Windows 95 and Windows 98 installation notes

        This information applies to the Windows 95 and Windows 98 operating
        systems.

        When installing an EtherLink NIC under Windows 95/98, the operating 
        system automatically detects the presence of the NIC and asks for 
        the diskette containing the driver software for the NIC (EtherDisk 
        diskette 1).  At this point, you can choose to cancel the installation 
        of driver software and install it later.  Even though the driver 
        installation has been canceled, the fact that the NIC is installed 
        is recorded in the System Registry.

        Later, when you install the driver software using the Network 
        icon in the Windows Control Panel, the operating system assumes that you
        are installing another instance of a NIC, not installing 
        software for the already recorded instance.  This results in two 
        instances of the NIC being recorded in the System Registry.  
        The EtherLink NIC does not operate correctly under these circumstances.

        To fix this problem, open the System icon in the Windows Control Panel.  
        In the Device Manager, under Network adapters, the two instances of 
        the EtherLink NIC are shown.  Remove the one that is marked disabled, 
        and restart your computer. The entry for the remaining EtherLink NIC 
        in the same dialog box should show that the NIC is operating 
        correctly.    
        

        >>> Error: " Invalid PCI Interrupt Level, Probable Hardware
        >>> Incompatibility" while executing DOS diagnostics

        3Com has observed that some PCs may display the above error message
        when the DOS diagnostics is launched. To avoid this problem, the 
        "Plug & Play O/S " option should be disabled in the system BIOS.
        Consult your PC's documentation for the proper steps to disable this 
        option.


        >>> DOS Configuration and Diagnostics program unable to recognize 
        >>> 3C90x NICs in Windows NT 3.51 and Windows NT 4.0

        3Com has observed that the DOS Configuration and Diagnostics program
        occasionally does not recognize 3C90x NICs when running under 
        Windows NT 3.51 or Windows NT 4.0.  To avoid this problem, boot your 
        PC with a DOS-bootable diskette and then launch the program.


        >>> When running the DOS diagnostics program (3C90XCFG.EXE) on a NIC 
        >>> with an MBA boot ROM installed, the N-WAY Auto Select option 
        >>> sometimes disappears from the list. Re-running the diagnostics 
        >>> without rebooting restores all available settings.

        This situation was observed intermittently on multiple machines but does
        not have any impact on the performance of the NIC.


        >>> When running the DOS diagnostics program (3C90XCFG.EXE), the 
        >>> diagnostic tests take the NIC off-line and force the link to 
        >>> 10 Mbps Half Duplex. Running the Group1 test forces a link 
        >>> renegotiation and the correct speed is set. Link renegotiation 
        >>> can also be forced by disconnecting and reconnecting the cables. 
        >>> These change of states can be observed with the NIC link (LNK) LED 
        >>> lights and the switch port status.

        This scenario was observed only when the NIC was set to NWAY - Auto and
        connected to a LinkSwitch 3000 port that was also set to auto negotiate.
        This situation however does not have any impact on the performance of
        the NIC.


        >>> Error when running the DOS Diagnostics program (3C90XCFG.EXE) from 
        >>> a DOS window under Windows 98

        To avoid possible errors, 3Com suggests booting from a DOS-bootable 
        diskette when running the DOS diagnostics program (3C90XCFG.EXE).
        Alternatively, the DOS diagnostics program can be run by rebooting 
        your PC in "Safe Mode - Command Prompt Only".


        >>> 3C90x-COMBO NICs require a reboot to reestablish network connectivity
        >>> when switching between ports on the NIC

        When changing from one port to another on a 3C90x-COMBO NIC, you must 
        reboot your PC in order to establish a network connection. This includes 
        any change from AUI or BNC to TP, TP to BNC or AUI, and any changes between
        BNC and AUI.


        >>> Windows NT and 3Com NIC Diagnostics program for Windows

        Because of security features in the Windows NT operating system, the 
        3Com Diagnostics program for Windows only functions for users with 
        Administrator privileges. If you have User privileges only, use the 
        3Com Configuration and Diagnostics program for DOS.


        >>> Intermittent LED behavior on 3C905/3C905B NICs

        3Com has observed that your PC must be power cycled after you have
        changed speed settings from 10 Mbps to 100 Mbps. The reboot allows
        the LEDs to indicate the correct speed settings.


        >>> Client 32 installations in Windows 98

        3Com does not recommend using the ODI LAN driver for Client 32
        installations under Windows 98.  The Windows NDIS driver should be
        used instead. 


         >>> Changing media type or duplex mode in 3Com NIC Diagnostics
            program using the NDIS 3 driver in Windows 95 (Retail)

        When you change the media type or duplex mode using the 3Com
        NIC Diagnostics program for Windows, you must exit the diagnostics
        program and reboot the PC for the changes to take effect.


        >>> DynamicAccess control panel icon disabled after removing
            the 3Com NIC Diagnostics program

        If you remove the 3Com NIC Diagnostics program on a PC running
        Windows 98 or Windows 95 (OSR2) with the DynamicAccess LAN agent
        installed, the DynamicAccess control panel icon will be disabled.
        Remove and reinstall the DynamicAccess LAN agent to fix the 
        problem.


        >>> Plug-and-play operating system using DOS

        If your PC has a "Plug-and-Play OS" setting in the BIOS,
        set this setting to NO if you are using DOS.  The "Plug-and-Play"        
        BIOS setting should be set to YES only if you are using a 
        plug-and-play capable operating system (such as Windows 95
        or Windows 98).


        >>> Installing the DynamicAccess LAN agent in a Windows 95
            PC that does not have a NIC installed

        Do not install the DynamicAccess LAN agent on a PC that
        does not have a NIC installed.

        If you do install DynamicAccess on a PC that does not have
        a NIC installed, the following error message will appear
        after a few moments:
        
        "3Com Dynamic Access Software did not install successfully. 
         From the start button run DAW95RMV.EXE..."

        Do not run the DAW95RMV.EXE program.  See the DynamicAccess
        Software User Guide, located with the DynamicAccess LAN Agent
        software on the EtherCD, for instructions on how to remove the 
        DynamicAccess LAN Agent.


    Frequently Asked Questions 
    --------------------------

        NOTE:  Specific FAQs for Remote Wake-Up are in the WAKEFAQ.TXT
               file located in the HELP directory on the EtherCD (or
               EtherDisk diskette 2).


        Q:  How do I remove the software that comes with my EtherLink NIC 
            from my system if I have a compatibility problem?
        
        A:  You may remove the 3Com NIC Diagnostics program from your system at
            any time by running the uninstaller in the Add/Remove Programs
            Control Panel. If you remove all of the EtherLink NICs from the 
            Control Panel, the uninstall program will be run automatically.

        
        Q:  Which PCI slot is best for my 3Com EtherLink 10/100 PCI NIC?
       
        A:  3Com PCI NICs are designed to work PCI slots that support 
            bus-mastering data transfers.  Refer to your owner's manual
            for information on which slots support bus-mastering data transfers.

       
        Q:  Which PCI slot(s) are "bus mastering" in my PCI machine?

        A:  Generally, if you have three PCI slots in a machine, one slot is 
            designated as a "slave-only" slot (that is, it does not support 
            bus-mastering data transfers).  Slots are not always marked clearly
            to distinguish between slave-only and bus-mastering slots.  Refer to 
            your owner's manual or contact your computer manufacturer for this 
            information.  Also, make sure that you have the latest version of 
            your system's BIOS. 
      
        
        Q.  Does my PCI NIC support shared interrupts?
      
        A.  The drivers for the EtherLink NICs support shared interrupts.  
            However, because there is no industry-standard way to support shared 
            interrupts, other NICs may support them differently, or not at all.  
            If you have another PCI NIC that does not support shared interrupts 
            (for example, a SCSI host NIC), either contact the manufacturer for 
            a shared interrupt driver or try running the system setup program 
            to assign it a different interrupt.  

            3Com has found that OS/2 version 1.3 does not support shared 
            interrupts, but it is only a problem if you are using the 
            OS/2 NDIS 2.01 driver in LAN Manager version 2.2.  3Com has also 
            found some problems with sharing interrupts under Windows 95. 
            More details are available in the "Release Notes" section earlier 
            in this document.  If this is a problem, try using the 
            DOS Configuration and Diagnostic program to give each NIC 
            a different IRQ, and change the BIOS on your system to match.

        
        Q:  What interrupts should I avoid using with my 3Com EtherLink NIC?
      
        A:  You should avoid using any interrupts used by ISA/EISA boards that
            do not properly support shared interrupts (level-triggered).  If 
            you do not know or are unsure whether your NIC supports shared
            interrupts, then avoid using them.  In addition, try to avoid 
            using the same interrupt as that of your local hard drive 
            (normally IRQ 14 for IDE drives and IRQ 11 for most SCSI host
            NICs), because not all hard drives support shared interrupts at 
            this time.  For Novell NetWare servers, you should also avoid
            using IRQ 7 or 15.  These IRQs only support nonshared devices and
            may cause problems if they are shared between two devices.   

        
        Q:  Are the EtherLink ODI drivers Novell-certified?
         
        A:  Yes, 3Com's EtherLink ODI drivers are Novell tested and approved.                

        
        Q:  I've purchased an HP Pavilion machine and I want to connect it to
            my network, are there any issues?

        A:  The HP Pavilion PCs are designed for home use and as a standalone
            multimedia machine.  HP does not recommend using this PC as a network
            PC. Issues including no available resources, PCI bus errors, and PCI
            device detection problems could arise when installing a PCI NIC in 
            these PCs.  3Com and HP are working together to resolve this problem.   

        
        Q:  After installing Novell Client 32 for Windows 95, the error message
            "Your driver could not be disabled" appears when I try to run the 
            3Com NIC Diagnostics program for Windows. Why?

        A:  If the PC is configured with Novell Client 32 using the 32-bit ODI
            driver, the 3Com NIC Diagnostics program will not support driver
            suspension.  In order to run the diagnostics program, either boot the
            machine in MS-DOS mode and execute 3C90XCFG.EXE from EtherDisk 
            diskette 3 or reconfigure Novell Client 32 to use an NDIS driver.  
            For exact directions, refer to your Client 32 instructions.  If you do
            experience the above message when you attempt to run the 3Com NIC
            Diagnostics program for Windows, verify that the hardware device is 
            enabled before rebooting the machine. Perform these steps:

            1) Right-click on the My Computer icon, and then click Properties.
            2) Double-click Network adapters.  
            3) Double-click the 3Com EtherLink NIC.
            4) Make sure that the Current Configuration is checked on
               the Device Usage box.  If you have only one hardware profile, it 
               appears as "Original Configuration (Current)." If you have multiple 
               hardware profiles, check the box where the  NIC should be enabled.
            5) Click OK, and then OK again to save settings.

        
        Q:  How do I update my 3C90x drivers in Windows 95 (OSR2)?

        A:  You can update the drivers using the Update NIC Drivers option
            on the EtherCD.  See the W95NDIS.TXT file, located in the
            HELP directory on the EtherCD (or EtherDisk diskette 2), for
            instructions.

    
        Q:  Which NetWare server driver should I use?

        A:  The Hardware Support Module (HSM) standard for NetWare 4.11 is
            called HSM v3.3.  NetWare 4.11 requires an HSM v3.3-compliant LAN
            driver.  An HSM v3.3-compliant driver is located in the \NWSERVER
            directory on EtherDisk Diskette 3.  An HSM v3.3-compliant driver
            can also be used for NetWare versions 3.12 and 4.10.  See Novell
            for the correct NLMs and support files for this environment.  Other
            versions of NetWare are no longer supported on this EtherDisk
            release.

    
        Q:  Where can I find out more information on DynamicAccess technology?

        A:  For detailed information about DynamicAccess technology, go to the 
            3Com World Wide Web site: www.3com.com/dynamicaccess



3Com Technical Support
----------------------

Refer to the EtherLink NIC's user guide for technical support information.
This information is also available in the \HELP\SUPPORT.TXT file on the
EtherCD (or EtherDisk diskette 2).


3Com, EtherLink, EtherDisk, and DynamicAccess are registered trademarks 
of 3Com Corporation.


                  (%VER README.TXT - Release Notes v5.1.1)
