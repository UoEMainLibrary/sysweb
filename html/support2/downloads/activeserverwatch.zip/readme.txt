
Active Server Watcher: readme
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Program information
~~~~~~~~~~~~~~~~~~~

Program Archive Name:
 asw.zip
Program Name:
 Active Server Watcher
Program Version:
 1.0
Program Release Date:
 Oct 30, 2000
Target OS:
 Windows 95/98/ME/NT/2000
Program Description:
 Server monitoring utility
Software type:
 Freeware



Company information
~~~~~~~~~~~~~~~~~~~

Company Name:
  SmartLine Inc.
Author Name:
  Ashot Oganesyan K.
Contact WWW URL:
  http://www.ntutility.com



Description
~~~~~~~~~~~

Active Server Watcher (ASW) - easy to use tool that periodically checks
given Internet resources and notifies you when they become unavailable.
ASW can monitor Web pages and scripts (CGI, ASP, PHP, etc.). You are able
to define a list of resources you wish to monitor. If a resource from this
list becomes unavailable, ASW executes a special action (display message,
write log file, execute external file, etc.). Also, for each resource you
can define the periodicity of checking and number of retries. ASW detects
when your computer goes offline and stops checking for resources to prevent
you from the misoperation.



License agreement
~~~~~~~~~~~~~~~~~

Active Server Watcher is FREEWARE.

This license agreement is a legal agreement between you (either
an individual or a single entity) and and the author of this
software package.

By installing or otherwise using this software you agree to be
bound by this agreement.

If you do not agree to the terms of this Agreement, 
you may not install or use this software.

You may install and use an unlimited number of 
copies of this software on your computers.

The author will not make available Technical Support for this
Software. The author may, from time to time, revise or update
the Software. In so doing, the author incurs no obligation to
furnish such revision or updates to you.

THIS SOFTWARE IS DISTRIBUTED "AS IS".  NO WARRANTY OF ANY KIND 
IS EXPRESSED OR IMPLIED. YOU USE RTM AT YOUR OWN RISK. THE
AUTHOR WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF
PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR MISUSING THIS
SOFTWARE.


Installation
~~~~~~~~~~~~

Important! If you've got ASW not from our web page, but from the other
source (magazine CD or some software library), please visit our home
page - you'll probably find the later version.

To install ASW you should run the "setup.exe" and follow the instructions.




                                              Copyright(c) 2000 SmartLine Inc.
                                                          All rights reserved.
                          Active Server Watcher is trademark of SmartLine Inc.